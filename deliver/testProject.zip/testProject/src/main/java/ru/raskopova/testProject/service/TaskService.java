package ru.raskopova.testProject.service;

import ru.raskopova.testProject.model.entity.Task;

import java.time.LocalDate;
import java.util.List;

public interface TaskService {
    /**
     * @return возвращает лист всех заданий
     */
    public List<Task> getAllTasks();

    /**
     * @return добавляет новое задание
     */
    public Task addTask(Task task);

    /**
     * @param order_id
     * @return возвращает задание по номеру заказа
     */
    public Task getTaskByOrderID(int order_id);

    /**
     * @param date1
     * @param date2
     * @return возвращает задания в диапазоне указанных дат
     */
    public List<Task> getTaskByDatePeriod(LocalDate date1, LocalDate date2);

    /**
     * @param status
     * @return возвращает задания по статусу
     */
    public List<Task> getTaskByStatus (String status);

    /**
     *
     */
    public void addCallResult(int id, String status, String comment);

}
